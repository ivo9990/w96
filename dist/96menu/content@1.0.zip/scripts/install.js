w96.sys.execCmd("mdview", ["C:/local/96menu/welcome to 96menu.md"])
w96.sys.execFile("C:/local/96menu/96menu/96menu")