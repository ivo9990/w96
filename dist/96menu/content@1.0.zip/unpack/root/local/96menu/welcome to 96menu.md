# Welcome to 96menu!

96menu is a customizable application launcher for Windows 96

## How to use

96menu launches on startup

In the default config for 96menu to open the menu do `Ctrl + Enter`

Now in the text box you can search for any app in the `C:/system/programs` folder *(you can even search using their executable name!)*

You can run commands directly in the menu by doing `exec:<command>`
Calculations are also supported `calc:<math operation>`

To hide the menu press `Escape`

To close 96menu click on its tray icon

## Customize

The config files are located in `C:/user/appdata/96menu`

 - `style.css` is the menu style
 - `config.json` is where you configure the hotkey


> **Important:**  
> <div style="color: #ff6600; font-weight: bold; margin-top: 5px;">
> The config is loaded in each time the program is opened, reopening the menu using the hotkey will NOT reload the config!
></div>

### config.json

This file controls the global keyboard shortcut used to open and close the menu. It uses toggle switches for modifier keys (`Ctrl`, `Shift`, `Alt`) combined with a primary execution key.
